﻿using AutoMapper;
using Mithril.DTO;
using Mithril.Model;

namespace Mithril.Helper
{
    public class AutoMapperProfiles:Profile
    {
        public AutoMapperProfiles()
        {
            CreateMap<Timesheet, TimesheetDTO>().ReverseMap();
            CreateMap<User, UserDTO>().ReverseMap();
        }
    }
}

﻿using Mithril.Model;

namespace Mithril.DTO
{
    public class TimesheetDTO
    {
        public int TimesheetId { get; set; }
        public int UserId { get; set; }
        public string DateString { get; set; }
        public bool OnLeave { get; set; }
        public IEnumerable<Activity> ActivityList { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Identity.Data;
using Mithril.Model;
using System.Data;

namespace Mithril.Service
{
    public interface IAuthService
    {
        bool AddUser(User user);
        string Login(LoginRequests loginRequests);
        bool AddRole(Role role);
        List<Role> GetRolesById(IEnumerable<int> roleIds);

        //bool AssignRoleToUser(AddUserRole addUserRole);

    }
}

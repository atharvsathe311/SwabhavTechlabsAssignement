﻿using Mithril.Model;

namespace Mithril.Service
{
    public interface ITimesheetService
    {
        void Add(Timesheet timesheet);
        Task<IEnumerable<Timesheet>> GetAll();
        Task<Timesheet> GetById(int id);
        void Update(int id,Timesheet timesheet);
        void Delete(int id);
    }
}

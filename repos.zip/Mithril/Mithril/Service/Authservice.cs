﻿using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Mithril.Data;
using Mithril.Model;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Mithril.Service
{
    public class AuthService : IAuthService
    {
        private readonly TimesheetDbContext _context;
        private readonly IConfiguration _configuration;

        public AuthService(TimesheetDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public bool AddUser(User user)
        {
            try
            {
                _context.Users.Add(user);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public string Login(LoginRequests loginRequests)
        {
            try
            {
                if (loginRequests.Username != null && loginRequests.Password != null)
                {
                    var user = _context.Users.Include("Roles").FirstOrDefault(s => s.UserName == loginRequests.Username && s.Password == loginRequests.Password);
                    if (user != null)
                    {
                        var Claims = new List<Claim>
                        {
                            new Claim(JwtRegisteredClaimNames.Sub,_configuration["Jwt:Subject"]),
                            new Claim("UserId",user.Id.ToString()),
                            new Claim("UserName",user.UserName),
                        };

                        var roles = user.Roles;
                        foreach (var role in roles)
                        {
                            Claims.Add(new Claim(ClaimTypes.Role, role.Name));
                        }

                        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                        var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                        var token = new JwtSecurityToken(
                            _configuration["Jwt:Issuer"],
                            _configuration["Jwt:Audience"],
                            Claims,
                            expires: DateTime.UtcNow.AddMinutes(30),
                            signingCredentials: signIn);
                        var Token = new JwtSecurityTokenHandler().WriteToken(token);
                        return Token;
                    }
                    throw new Exception("Invalid Credentials");
                }
                throw new Exception("Empty Credentials");
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public bool AddRole(Role role)
        {
            try
            {
                _context.Roles.Add(role);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public List<Role> GetRolesById(IEnumerable<int> roleIds)
        {
            if (roleIds == null)
                return new List<Role>();

            var roles = _context.Roles.Where(r => roleIds.Contains(r.Id)).ToList();
            return roles;
        }
    }
}

﻿using Mithril.Model;
using Mithril.Repository;

namespace Mithril.Service
{
    public class TimeSheetService : ITimesheetService
    {
        private readonly IRepository<Timesheet> _repository;
        private readonly ITimesheetRepository _timesheetRepository;
        public TimeSheetService(ITimesheetRepository timesheetRepository,IRepository<Timesheet> repository) 
        {
            _repository = repository;
            _timesheetRepository = timesheetRepository;
        }

        public void Add(Timesheet timesheet)
        {
            _repository.Add(timesheet); 
        }

        public void Delete(int id)
        {
            _timesheetRepository.Delete(id);
        }

        public async Task<IEnumerable<Timesheet>> GetAll()
        {
            return await _timesheetRepository.GetAll();
        }

        public async Task<Timesheet> GetById(int id)
        {
            return await _timesheetRepository.GetById(id);
        }

        public void Update(int id, Timesheet timesheet)
        {
            _timesheetRepository.Update(id,timesheet);
        }
    }
}

﻿namespace Mithril.Model
{
    public class LoginRequests
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}

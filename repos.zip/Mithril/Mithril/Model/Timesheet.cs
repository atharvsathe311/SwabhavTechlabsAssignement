﻿namespace Mithril.Model
{
    public class Timesheet
    {
        public int TimesheetId { get; set; }
        public int UserId { get; set; }
        public DateOnly Date {  get; set; }
        public bool OnLeave { get; set; }
        public IEnumerable<Activity> ActivityList { get; set; }
    }
}

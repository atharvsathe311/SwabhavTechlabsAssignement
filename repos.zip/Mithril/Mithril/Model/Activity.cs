﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Mithril.Model
{
    public class Activity
    {
        public int ActivityId { get; set; }
        public string Project {  get; set; }
        public string SubProject { get; set; }
        public string Batch { get; set; }
        public string HoursNeeded { get; set; }
        public string Description {  get; set; }

        [ForeignKey("Timesheet")]
        public int TimesheetId { get; set; }
    }
}

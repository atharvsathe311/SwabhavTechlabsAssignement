﻿using Microsoft.EntityFrameworkCore;
using Mithril.Model;

namespace Mithril.Data
{
    public class TimesheetDbContext:DbContext
    {
        public DbSet<Timesheet> Timesheets { get; set; }
        public DbSet<Activity> Activities { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }
        public TimesheetDbContext(DbContextOptions dbContextOptions) : base(dbContextOptions) { }

    }
}

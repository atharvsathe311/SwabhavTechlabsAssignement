﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Mithril.DTO;
using Mithril.Model;
using Mithril.Service;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Mithril.Controllers
{
    [Authorize(Roles = "Admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class TimesheetController : ControllerBase
    {
        private readonly ITimesheetService _timesheetService;
        private readonly IMapper _mapper;
        public TimesheetController(ITimesheetService timesheetService,IMapper mapper) 
        {
            _timesheetService = timesheetService;
            _mapper = mapper;
        }
        // GET: api/<TimesheetController>
        [HttpGet]
        public async Task<IEnumerable<Timesheet>> Get()
        {
            return await _timesheetService.GetAll();
        }

        // GET api/<TimesheetController>/5
        [HttpGet("{id}")]
        public async Task<Timesheet> Get(int id)
        {
            return await _timesheetService.GetById(id);
        }

        // POST api/<TimesheetController>
        [HttpPost]
        public void Post([FromBody] TimesheetDTO timesheetDTO)
        {
            var timesheet = _mapper.Map<Timesheet>(timesheetDTO);
            timesheet.Date = DateOnly.ParseExact(timesheetDTO.DateString,"yyyy/mm/dd");
            _timesheetService.Add(timesheet);
        }

        // PUT api/<TimesheetController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] TimesheetDTO timesheetDTO)
        {
            var timesheet = _mapper.Map<Timesheet>(timesheetDTO);
            timesheet.Date = DateOnly.ParseExact(timesheetDTO.DateString,"dd/MM/yyyy");
            _timesheetService.Update(id,timesheet);
        }

        // DELETE api/<TimesheetController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _timesheetService.Delete(id);
        }
    }
}

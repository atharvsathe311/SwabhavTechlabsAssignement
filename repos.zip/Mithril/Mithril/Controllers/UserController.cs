﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Mithril.DTO;
using Mithril.Model;
using Mithril.Service;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Mithril.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly IMapper _mapper;
        public UserController(IAuthService authService, IMapper mapper)
        {
            _authService = authService;
            _mapper = mapper;
        }


        [HttpPost("AddUser")]
        public bool AddUser([FromBody] UserDTO userDto)
        {
            var user = _mapper.Map<User>(userDto);
            var roles = _authService.GetRolesById(userDto.RoleIds);
            user.Roles = roles;
            user.Password = user.Password;
            return _authService.AddUser(user);
        }

        [HttpPost("Login")]
        public string Login(LoginRequests loginRequests)
        {

            Console.WriteLine(loginRequests.Username, loginRequests.Password);
            return _authService.Login(loginRequests);
        }

        [HttpPost("AddRole")]
        public bool AddRole(Role role)
        {
            return _authService.AddRole(role);
        }
    }
}

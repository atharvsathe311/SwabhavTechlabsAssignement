﻿using Microsoft.EntityFrameworkCore;
using Mithril.Data;
using Mithril.Model;

namespace Mithril.Repository
{
    public class TimesheetRepository : ITimesheetRepository
    {
        private readonly TimesheetDbContext _context;
        public TimesheetRepository(TimesheetDbContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Timesheet>> GetAll()
        {
            return await _context.Timesheets.Include("ActivityList").ToListAsync();
        }

        public async Task<Timesheet> GetById(int id)
        {
            return await _context.Timesheets.Include("ActivityList").SingleOrDefaultAsync(s=>s.TimesheetId == id);
        }

        public void Update(int id,Timesheet timesheet)
        {
            Timesheet timesheet1 = _context.Timesheets.SingleOrDefault(s => s.TimesheetId== id);
            timesheet1.UserId = timesheet.UserId;
            timesheet1.Date = timesheet.Date;
            timesheet1.OnLeave = timesheet.OnLeave;
            timesheet1.ActivityList = timesheet.ActivityList;
            _context.SaveChanges();
        }

        public async void Delete(int id)
        {
            Timesheet timesheet = await GetById(id);
            _context.Timesheets.Remove(timesheet);
        }
    }
}

﻿using Mithril.Model;

namespace Mithril.Repository
{
    public interface ITimesheetRepository
    {
        Task<IEnumerable<Timesheet>> GetAll();
        Task<Timesheet> GetById(int id);
        void Update(int id,Timesheet timesheet);
        void Delete(int id);
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Mithril.Data;

namespace Mithril.Repository
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly TimesheetDbContext _timesheetDbContext;
        private readonly DbSet<T> _dbSet;
        public Repository(TimesheetDbContext timesheetDbContext) 
        {
            _timesheetDbContext = timesheetDbContext;
            _dbSet = timesheetDbContext.Set<T>();
        }
        public void Add(T entity)
        {
            _dbSet.Add(entity);
            _timesheetDbContext.SaveChanges();          
        }
    }
}

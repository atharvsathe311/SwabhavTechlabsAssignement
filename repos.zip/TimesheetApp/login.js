
document.getElementById('loginForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const crdentials = { "username": username, "password": password }
        console.log(crdentials);

        const response = await fetch('http://localhost:5124/api/User/Login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(crdentials)
        });

        const responseText = await response.text();

        if (responseText === 'Empty Credentials' || responseText === 'Invalid Credentials') {
            throw new Error(responseText);
        }

        const token = responseText;
        sessionStorage.setItem('authToken', token);
        window.location.href = 'index.html';
    } catch (error) {
        document.getElementById('errorMessage').style.display = 'block';
        console.error('Error:', error);
    }
});
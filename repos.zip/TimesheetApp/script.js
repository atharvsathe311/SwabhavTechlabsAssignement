const url = "http://localhost:5124/api/Timesheet";
let formData = {} ;
let activityElement = document.getElementById("timsheets");

const ActivityAdder = () => {

    activityElement.insertAdjacentHTML('beforeend',`
                <div activity class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="project">Project</label>
                                <select class="form-control" id="project">
                                    <option>Select Project</option>
                                </select>
                            </div>
                        </div>
        
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="subProject">Sub-Project</label>
                                <select class="form-control" id="subProject">
                                    <option>Select Sub-Project</option>
                                </select>
                            </div>
                        </div>
        
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="batch">Batch</label>
                                <select class="form-control" id="batch">
                                    <option>Select Batch</option>
                                </select>
                            </div>
                        </div>
                    </div>
        
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="hoursNeeded">Hours Needed</label>
                                <div class="d-flex">
                                    <input type="number" class="form-control mr-2" id="hoursNeededHours" placeholder="00">
                                    <h4 class="mr-2">:</h4>
                                    <input type="number" class="form-control" id="hoursNeededMinutes" placeholder="00">
                                </div>
                            </div>
                        </div>
                    </div>
        
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="activity">Activity</label>
                                <textarea class="form-control" id="activity" rows="5" placeholder="Enter activity details"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                </div>`);
}

let addActivity = document.getElementById("activity-button");
addActivity.addEventListener(("click"), () => {
    ActivityAdder();
})

ActivityAdder();

const Preview = () => {
    let form = document.getElementById("activity-form");
    let date = form.querySelector("#date").value;
    let onLeave = (form.querySelector("#onLeave").value === "Yes");

    let activities = [];
    let activityCards = document.querySelectorAll("#timsheets .card");

    activityCards.forEach(card => {
        let project = card.querySelector("#project").value;
        let subProject = card.querySelector("#subProject").value;
        let batch = card.querySelector("#batch").value;
        let hoursNeededHours = card.querySelector("#hoursNeededHours").value;
        let hoursNeededMinutes = card.querySelector("#hoursNeededMinutes").value;
        let activityDetails = card.querySelector("#activity").value;

        activities.push({
            activityId : 0,
            project: project,
            subProject: subProject,
            batch: batch,
            hoursNeeded: `${hoursNeededHours}:${hoursNeededMinutes}`,
            description: activityDetails,
            timesheetId: 0
        });
    });

    formData = {
        date: date,
        onLeave: onLeave,
        activities: activities
    };
    GenerateTable(formData);
}

const CalculateTotalHours = (projects) => {
    let totalMinutes = 0;
    console.log(projects);
    
    projects.forEach(project => {
        const hours = parseInt(project.hoursNeeded.slice(0, 2), 10) || 0;    
            const minutes = parseInt(project.hoursNeeded.slice(3), 10) || 0;
    
        totalMinutes += (hours * 60) + minutes;
    });

    const totalHours = Math.floor(totalMinutes / 60);
    const remainingMinutes = totalMinutes % 60;
    return `${totalHours} hrs ${remainingMinutes} mins`;
};

function parseTime(timeStr) {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return (hours || 0) * 60 + (minutes || 0);
}

// Function to format total minutes to hours:minutes string
function formatTime(totalMinutes) {
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${hours}:${minutes.toString().padStart(2, '0')}`;
}

const GenerateTable = (data) => {
    const table = document.querySelector("#dynamicTable tbody");

    table.innerHTML = "";
    let totalMinutes = 0 ;

    data.activities.forEach(activity => {
        totalMinutes += parseTime(activity.hoursNeeded);
    });

    data.activities.forEach((activity, index) => {
        const row = document.createElement('tr');

        if (index === 0) { 
            row.innerHTML = `
            <td rowspan="${data.activities.length}">${index + 1}</td>
            <td rowspan="${data.activities.length}">${data.date}</td>
            <td rowspan="${data.activities.length}">${data.onLeave}</td>
        `;
        }

        row.innerHTML += `
        <td>${activity.project}</td>
        <td>${activity.subProject}</td>
        <td>${activity.batch}</td>
        <td>${activity.description}</td>
        <td>${activity.hoursNeeded}</td>
        ${index === 0 ? `<td rowspan="${data.activities.length}">${formatTime(totalMinutes)}</td>` : ''}
    `;

        table.appendChild(row);
    });
}

const Cancel = () => 
    {
        let form = document.querySelector("form");
        form.reset();
    }

const OnSave = async () => 
{
    const token = sessionStorage.getItem('authToken');
    let decoded = {}
    if (token) {
        try {
            // Decode the token using jwt-decode
            decoded = jwt_decode(token);
            console.log('Decoded JWT payload:', decoded);
        } catch (error) {
            console.error('Error decoding JWT token:', error);
        }
    }

    const body = 
        {
            "timesheetId": 0,
            "userId": Number(decoded.UserId),
            "dateString": formData.date,
            "onLeave": formData.onLeave,
            "activityList": formData.activities
        }
        
        const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(body)
      })

      if(response.status == 401 )
        {
            alert("Session Timeout");
            const token = sessionStorage.clear();
            window.location.href = "login.html";
            return;
        }

      if(response.ok)
        {
            window.location.href = "index2.html";
      }
}



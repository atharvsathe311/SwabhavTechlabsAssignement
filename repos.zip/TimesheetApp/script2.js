const token = sessionStorage.getItem('authToken');

const GetData = async () => {
    const response = await fetch("http://localhost:5124/api/Timesheet", {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    });

    console.log(response.status);
    
    if(response.status == 401 )
        {
            const token = sessionStorage.clear();
            window.location.href = "login.html";
            return;
        }
    
    const data = await response.json();
    GenerateTable(data)
}

GetData()

const CalculateTotalHours = (projects) => {
    let totalMinutes = 0;
    // console.log(projects);

    projects.forEach(project => {
        const hours = parseInt(project.hoursNeeded.slice(0, 2), 10) || 0;
        const minutes = parseInt(project.hoursNeeded.slice(3), 10) || 0;

        totalMinutes += (hours * 60) + minutes;
    });

    const totalHours = Math.floor(totalMinutes / 60);
    const remainingMinutes = totalMinutes % 60;
    return `${totalHours} hrs ${remainingMinutes} mins`;
};

function parseTime(timeStr) {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return (hours || 0) * 60 + (minutes || 0);
}

// Function to format total minutes to hours:minutes string
function formatTime(totalMinutes) {
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${hours}:${minutes.toString().padStart(2, '0')}`;
}

const GenerateTable = (data) => {
    const table = document.querySelector("#dynamicTable tbody");
    let newdata = JSON.stringify(data)

    table.innerHTML = "";

    data.forEach(timesheet => {
        // Iterate over each activity in the activityList
        let totalMinutes = 0 ;

        timesheet.activityList.forEach(activity => {
            totalMinutes += parseTime(activity.hoursNeeded);
        });
        timesheet.activityList.forEach((activity, index) => {
            const row = document.createElement('tr');

            // Add the first row with merged cells
            if (index === 0) {
                row.innerHTML = `
                <td rowspan="${timesheet.activityList.length}">${timesheet.timesheetId}</td>
                <td rowspan="${timesheet.activityList.length}">${timesheet.date}</td>
                <td rowspan="${timesheet.activityList.length}">${timesheet.onLeave}</td>
                <td>${activity.project}</td>
                <td>${activity.subProject}</td>
                <td>${activity.batch}</td>
                <td>${activity.description}</td>
                <td>${activity.hoursNeeded}</td>
                 <td rowspan="${timesheet.activityList.length}">${formatTime(totalMinutes)}</td>
            `;
            } else {
                // Add subsequent rows for remaining activities
                row.innerHTML = `
                <td>${activity.project}</td>
                <td>${activity.subProject}</td>
                <td>${activity.batch}</td>
                <td>${activity.description}</td>
                <td>${activity.hoursNeeded}</td>
            `;
            }

            // Append the row to the table
            table.appendChild(row);
        });
    });

}

